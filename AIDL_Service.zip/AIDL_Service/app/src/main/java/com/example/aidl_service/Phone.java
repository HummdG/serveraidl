package com.example.aidl_service;

import android.os.Parcel;
import android.os.Parcelable;

public class Phone implements Parcelable {
    private String name;
    private String colour;
    private String model;

    // Constructor
    public Phone(String name, String colour, String model) {
        this.name = name;
        this.colour = colour;
        this.model = model;
    }

    // Getter methods
    public String getName() {
        return name;
    }

    public String getColour() {
        return colour;
    }

    public String getModel() {
        return model;
    }

    // Parcelable implementation
    protected Phone(Parcel in) {
        name = in.readString();
        colour = in.readString();
        model = in.readString();
    }

    public static final Creator<Phone> CREATOR = new Creator<Phone>() {
        @Override
        public Phone createFromParcel(Parcel in) {
            return new Phone(in);
        }

        @Override
        public Phone[] newArray(int size) {
            return new Phone[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(colour);
        dest.writeString(model);
    }
}
