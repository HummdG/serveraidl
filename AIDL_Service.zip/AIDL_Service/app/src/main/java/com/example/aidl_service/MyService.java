package com.example.aidl_service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.widget.TextView;

public class MyService extends Service {

    // Store latitude and longitude
    private double latitude = 0.0;
    private double longitude = 0.0;

    @Override
    public IBinder onBind(Intent intent) {
        return aidlBinder;
    }

    // AIDL Binder
    private final aidlInterface.Stub aidlBinder = new aidlInterface.Stub() {

        // Get random latitude and longitude
        @Override
        public double[] getRandomLatLong() throws RemoteException {
            latitude = getRandomLatitude();
            longitude = getRandomLongitude();
            return new double[]{latitude, longitude};
        }

        // Set new latitude and longitude
        @Override
        public void setNewLatLong(double lat, double lon) throws RemoteException {
            latitude = lat;
            longitude = lon;

            // Call a method to update the UI
            updateLocationInUI(lat, lon);
        }
        @Override
        public Phone getPhoneDetails() throws RemoteException {
            // Return a new Phone object with sample data
            return new Phone("Samsung", "Black", "Galaxy S21");
        }
    };

    // Generate random latitude
    private double getRandomLatitude() {
        return Math.random() * 180 - 90; // Random latitude between -90 and 90
    }

    // Generate random longitude
    private double getRandomLongitude() {
        return Math.random() * 360 - 180; // Random longitude between -180 and 180
    }

    // Method to update the UI with the new latitude and longitude
    private void updateLocationInUI(final double lat, final double lon) {
        MainActivity mainActivity = MainActivity.getInstance();
        if (mainActivity != null) {
            mainActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // Update TextViews in MainActivity with new values
                    TextView latTextView = mainActivity.findViewById(R.id.lat_display);
                    TextView longTextView = mainActivity.findViewById(R.id.long_display);

                    latTextView.setText("Latitude: " + lat);
                    longTextView.setText("Longitude: " + lon);
                }
            });
        }
    }
}
